// Gruntfile.js
module.exports = function (grunt) {
    // load all grunt tasks matching the ['grunt-*', '@*/grunt-*'] patterns
    require('load-grunt-tasks')(grunt);

	grunt.loadNpmTasks('ngAnnotate');
	grunt.loadNpmTasks('grunt-contrib-uglify');

	grunt.registerTask('default', ['ngAnnotate', 'uglify']);
	
    grunt.initConfig({
		// Task configuration.
		ngAnnotate: {
			demo: {
				files: {					
					'_AccountControllerDI.js': ['_AccountController.js'],
					'_ClientControllerDI.js': ['_ClientController.js'],
					'_DashboardControllerDI.js': ['_DashboardController.js'],
					'_GeneralPageControllerDI.js': ['_GeneralPageController.js'],
					'_ResourcesControllerDI.js': ['_ResourcesController.js'],
					'_SuperRecCallFLowControllerDI.js': ['_SuperRecCallFLowController.js'],
					'_SuperRecControllerDI.js': ['_SuperRecController.js'],
					'_TodoControllerDI.js': ['_TodoController.js'],
					'_UISelectControllerDI.js': ['_UISelectController.js'],
					'_UserProfileControllerDI.js': ['_UserProfileController.js'],
					'_LoginControllerDI.js': ['_LoginController.js'],
					'_PlanControllerDI.js': ['_PlanController.js']
				}
			},
		},
		uglify: {
			demo: {
				files: {
					'PlanController.js': ['_PlanControllerDI.js'],
					'LoginController.js': ['_LoginControllerDI.js'],
					'UserProfileController.js': ['_UserProfileControllerDI.js'],
					'UISelectController.js': ['_UISelectControllerDI.js'],
					'TodoController.js': ['_TodoControllerDI.js'],
					'SuperRecController.js': ['_SuperRecControllerDI.js'],
					'SuperRecCallFLowController.js': ['_SuperRecCallFLowControllerDI.js'],
					'ResourcesController.js': ['_ResourcesControllerDI.js'],
					'GeneralPageController.js': ['_GeneralPageControllerDI.js'],
					'DashboardController.js': ['_DashboardControllerDI.js'],
					'ClientController.js': ['_ClientControllerDI.js'],
					'AccountController.js': ['_AccountControllerDI.js'],
					
					
					
					
					
					
					
					
					
					
					
					
				}
			}
		}		
		
	});
	
    //grunt.registerTask('default', []);
}
